# Santimpay Payment Integration - API Reference

Complete API documentation for all Santimpay payment integration endpoints.

## 📋 Table of Contents

1. [Wallet Endpoints](#wallet-endpoints)
2. [Payment Endpoints](#payment-endpoints)
3. [Subscription Payment Endpoints](#subscription-payment-endpoints)
4. [Webhook Endpoints](#webhook-endpoints)
5. [Response Formats](#response-formats)
6. [Error Codes](#error-codes)

---

## 🏦 Wallet Endpoints

### POST /api/wallet/topup

Initiate a wallet topup transaction.

**Authentication:** Required (Bearer Token)

**Request Body:**
```json
{
  "amount": 100,
  "paymentMethod": "Telebirr",
  "reason": "Wallet topup"
}
```

**Parameters:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| amount | number | Yes | Amount to topup (must be > 0) |
| paymentMethod | string | Yes | Payment method (Telebirr, CBE, MPesa, etc.) |
| reason | string | No | Transaction reason/description |
| payment_option_id | string | No | Payment option ID (alternative to paymentMethod) |

**Response (202 Accepted):**
```json
{
  "message": "Topup initiated",
  "transactionId": "550e8400-e29b-41d4-a716-446655440000",
  "gatewayTxnId": "GW-TXN-123456789"
}
```

**Error Responses:**
```json
// 400 - Invalid amount
{
  "message": "amount must be > 0"
}

// 400 - Missing phone
{
  "message": "phoneNumber missing in token"
}

// 400 - Invalid phone format
{
  "message": "Invalid phone format in token. Required: +2519XXXXXXXX"
}

// 400 - Missing payment method
{
  "message": "paymentMethod is required and no payment preference is set"
}

// 500 - Gateway error
{
  "message": "payment failed"
}
```

**Example cURL:**
```bash
curl -X POST http://localhost:5000/api/wallet/topup \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 100,
    "paymentMethod": "Telebirr",
    "reason": "Wallet topup"
  }'
```

---

### GET /api/wallet/balance

Get current wallet balance for authenticated user.

**Authentication:** Required (Bearer Token)

**Response (200 OK):**
```json
{
  "balance": 500.50,
  "currency": "ETB",
  "lastTransactionAt": "2024-01-15T10:30:00Z"
}
```

**Example cURL:**
```bash
curl -X GET http://localhost:5000/api/wallet/balance \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### GET /api/wallet/transactions

Get transaction history for authenticated user.

**Authentication:** Required (Bearer Token)

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| limit | number | Number of transactions (default: 20) |
| offset | number | Pagination offset (default: 0) |
| type | string | Filter by type: 'credit' or 'debit' |
| status | string | Filter by status: 'pending', 'success', 'failed' |

**Response (200 OK):**
```json
{
  "transactions": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "refId": "REF-123456",
      "txnId": "GW-TXN-123456789",
      "amount": 100,
      "type": "credit",
      "method": "santimpay",
      "status": "success",
      "msisdn": "+251911223344",
      "createdAt": "2024-01-15T10:30:00Z",
      "metadata": {
        "reason": "Wallet topup",
        "paymentVia": "Telebirr"
      }
    }
  ],
  "total": 50,
  "limit": 20,
  "offset": 0
}
```

**Example cURL:**
```bash
curl -X GET "http://localhost:5000/api/wallet/transactions?limit=10&status=success" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### POST /api/wallet/webhook

Santimpay callback endpoint (public - no authentication required).

**Request Body:**
```json
{
  "TxnId": "GW-TXN-123456789",
  "Status": "COMPLETED",
  "amount": 100,
  "msisdn": "+251911223344",
  "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000",
  "commission": 5,
  "totalAmount": 105,
  "reason": "Wallet topup"
}
```

**Parameters:**
| Field | Type | Description |
|-------|------|-------------|
| TxnId | string | Gateway transaction ID |
| Status | string | Transaction status (COMPLETED, FAILED, CANCELLED, etc.) |
| amount | number | Transaction amount |
| msisdn | string | Customer phone number |
| thirdPartyId | string | Our transaction ID |
| commission | number | Commission amount |
| totalAmount | number | Total amount including commission |

**Response (200 OK):**
```json
{
  "ok": true,
  "txnId": "GW-TXN-123456789",
  "refId": "REF-123456",
  "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000",
  "status": "COMPLETED",
  "amount": 100,
  "currency": "ETB",
  "msisdn": "+251911223344",
  "updatedAt": "2024-01-15T10:30:00Z"
}
```

**Error Response (200 OK - always acknowledge):**
```json
{
  "ok": false,
  "message": "Transaction not found for webhook",
  "thirdPartyId": "unknown-id",
  "txnId": "GW-TXN-123456789"
}
```

---

### GET /api/wallet/admin/balances

Admin endpoint to view all user wallet balances.

**Authentication:** Required (Admin role)

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| limit | number | Number of records (default: 20) |
| offset | number | Pagination offset (default: 0) |
| sortBy | string | Sort field: 'balance' or 'createdAt' |
| order | string | Sort order: 'ASC' or 'DESC' |

**Response (200 OK):**
```json
{
  "wallets": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "userId": "user-123",
      "balance": 500.50,
      "lastTransactionAt": "2024-01-15T10:30:00Z",
      "createdAt": "2024-01-10T08:00:00Z"
    }
  ],
  "total": 150,
  "limit": 20,
  "offset": 0
}
```

---

### GET /api/wallet/admin/transactions

Admin endpoint to view all transactions.

**Authentication:** Required (Admin role)

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| limit | number | Number of transactions (default: 20) |
| offset | number | Pagination offset (default: 0) |
| userId | string | Filter by user ID |
| type | string | Filter by type: 'credit' or 'debit' |
| status | string | Filter by status: 'pending', 'success', 'failed' |
| method | string | Filter by method: 'santimpay', etc. |

**Response (200 OK):**
```json
{
  "transactions": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "userId": "user-123",
      "amount": 100,
      "type": "credit",
      "status": "success",
      "method": "santimpay",
      "msisdn": "+251911223344",
      "createdAt": "2024-01-15T10:30:00Z"
    }
  ],
  "total": 500,
  "limit": 20,
  "offset": 0
}
```

---

## 💳 Payment Endpoints

### POST /api/payments

Create a new payment record (manual payment submission).

**Authentication:** Required (Passenger or Admin)

**Request Body:**
```json
{
  "subscription_id": "550e8400-e29b-41d4-a716-446655440000",
  "amount": 4218.60,
  "payment_method": "BANK_TRANSFER",
  "transaction_reference": "PAY-123456789",
  "due_date": "2024-02-15"
}
```

**Parameters:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| subscription_id | string | Yes | Subscription UUID |
| amount | number | No | Payment amount (inferred from subscription if missing) |
| payment_method | string | Yes | Payment method |
| transaction_reference | string | No | Reference number |
| due_date | string | No | Due date (YYYY-MM-DD) |

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Payment submitted for admin approval",
  "paymentId": "550e8400-e29b-41d4-a716-446655440000",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "subscription_id": "550e8400-e29b-41d4-a716-446655440001",
    "amount": 4218.60,
    "payment_method": "BANK_TRANSFER",
    "status": "PENDING",
    "admin_approved": false,
    "createdAt": "2024-01-15T10:30:00Z"
  }
}
```

---

### GET /api/payments

List payments (filtered by user role).

**Authentication:** Required (Passenger or Admin)

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| limit | number | Number of records (default: 20) |
| offset | number | Pagination offset (default: 0) |
| status | string | Filter by status: 'PENDING', 'SUCCESS', 'FAILED' |
| subscription_id | string | Filter by subscription ID |

**Response (200 OK):**
```json
{
  "payments": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "subscription_id": "550e8400-e29b-41d4-a716-446655440001",
      "amount": 4218.60,
      "payment_method": "BANK_TRANSFER",
      "status": "PENDING",
      "admin_approved": false,
      "createdAt": "2024-01-15T10:30:00Z"
    }
  ],
  "total": 10,
  "limit": 20,
  "offset": 0
}
```

---

### GET /api/payments/pending

Admin endpoint to view pending payments.

**Authentication:** Required (Admin role)

**Response (200 OK):**
```json
{
  "payments": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "subscription_id": "550e8400-e29b-41d4-a716-446655440001",
      "passenger_id": "user-123",
      "amount": 4218.60,
      "payment_method": "BANK_TRANSFER",
      "status": "PENDING",
      "admin_approved": false,
      "transaction_reference": "PAY-123456789",
      "createdAt": "2024-01-15T10:30:00Z"
    }
  ],
  "total": 5
}
```

---

### PATCH /api/payments/:id/approve

Admin endpoint to approve a payment.

**Authentication:** Required (Admin role)

**Request Body:**
```json
{
  "notes": "Payment verified"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Payment approved successfully",
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "SUCCESS",
    "admin_approved": true,
    "approved_by": "admin-123",
    "approved_at": "2024-01-15T10:35:00Z"
  },
  "subscription": {
    "id": "550e8400-e29b-41d4-a716-446655440001",
    "status": "ACTIVE"
  }
}
```

---

### PATCH /api/payments/:id/reject

Admin endpoint to reject a payment.

**Authentication:** Required (Admin role)

**Request Body:**
```json
{
  "rejection_reason": "Invalid transaction reference"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Payment rejected successfully",
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "FAILED",
    "rejection_reason": "Invalid transaction reference",
    "approved_by": "admin-123",
    "approved_at": "2024-01-15T10:35:00Z"
  }
}
```

---

### GET /api/payments/:id

Get payment details.

**Authentication:** Required (Passenger or Admin)

**Response (200 OK):**
```json
{
  "success": true,
  "payment": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "subscription_id": "550e8400-e29b-41d4-a716-446655440001",
    "passenger_id": "user-123",
    "amount": 4218.60,
    "payment_method": "BANK_TRANSFER",
    "status": "PENDING",
    "admin_approved": false,
    "transaction_reference": "PAY-123456789",
    "createdAt": "2024-01-15T10:30:00Z"
  }
}
```

---

## 🚗 Subscription Payment Endpoints

### POST /api/subscription/:id/payment

Process payment for a subscription using Santimpay gateway.

**Authentication:** Required (Bearer Token - Passenger)

**Request Body:**
```json
{
  "payment_method": "Telebirr",
  "payment_option_id": "optional-payment-option-id"
}
```

**Parameters:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| payment_method | string | No | Payment method (Telebirr, CBE, etc.) |
| payment_option_id | string | No | Payment option ID |

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Subscription payment initiated",
  "data": {
    "subscription_id": "550e8400-e29b-41d4-a716-446655440000",
    "gatewayTxnId": "GW-TXN-123456789",
    "amount": 4218.60,
    "payment_method": "Telebirr"
  }
}
```

**Error Responses:**
```json
// 404 - Subscription not found
{
  "success": false,
  "message": "Subscription not found"
}

// 403 - Access denied
{
  "success": false,
  "message": "Access denied"
}

// 400 - Already paid
{
  "success": false,
  "message": "Subscription is already paid"
}

// 400 - Invalid amount
{
  "success": false,
  "message": "Invalid amount (must be > 0)."
}

// 400 - Invalid phone
{
  "success": false,
  "message": "Missing or invalid passenger phone; please ensure the token contains a valid +2519XXXXXXXX."
}

// 502 - Gateway error
{
  "success": false,
  "message": "Payment initiation failed: error details",
  "gateway_status": 400,
  "gateway_response": { }
}
```

**Example cURL:**
```bash
curl -X POST http://localhost:5000/api/subscription/550e8400-e29b-41d4-a716-446655440000/payment \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "payment_method": "Telebirr"
  }'
```

---

### POST /api/subscription/webhook

Subscription payment webhook (public - Santimpay callback).

**Request Body:**
```json
{
  "TxnId": "GW-TXN-123456789",
  "Status": "COMPLETED",
  "amount": 4218.60,
  "msisdn": "+251911223344",
  "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Response (200 OK):**
```json
{
  "ok": true,
  "subscription_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "PAID",
  "gatewayTxnId": "GW-TXN-123456789"
}
```

---

## 🔔 Webhook Endpoints

### POST /api/webhooks/public

Public webhook echo endpoint (for testing).

**Request Body:** Any JSON

**Response (200 OK):**
```json
{
  "ok": true,
  "receivedAt": "2024-01-15T10:30:00Z",
  "method": "POST",
  "path": "/api/webhooks/public",
  "body": { }
}
```

---

### POST /api/webhooks/payment

Payment provider webhook handler.

**Request Body:**
```json
{
  "txnId": "GW-TXN-123456789",
  "Status": "COMPLETED",
  "amount": 100,
  "msisdn": "+251911223344",
  "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Response (200 OK):**
```json
{
  "ok": true
}
```

---

## 📊 Response Formats

### Success Response Format

```json
{
  "success": true,
  "message": "Operation successful",
  "data": { }
}
```

### Error Response Format

```json
{
  "success": false,
  "message": "Error description",
  "error": "error-code"
}
```

### Paginated Response Format

```json
{
  "data": [ ],
  "total": 100,
  "limit": 20,
  "offset": 0,
  "hasMore": true
}
```

---

## ⚠️ Error Codes

| Code | Status | Description |
|------|--------|-------------|
| 400 | Bad Request | Invalid input or missing required fields |
| 401 | Unauthorized | Missing or invalid authentication token |
| 403 | Forbidden | User doesn't have permission for this action |
| 404 | Not Found | Resource not found |
| 409 | Conflict | Resource already exists or state conflict |
| 422 | Unprocessable Entity | Validation error |
| 500 | Internal Server Error | Server error |
| 502 | Bad Gateway | Payment gateway error |

---

## 📱 Payment Methods

Supported payment methods:

- **Telebirr** - Ethiopian mobile money
- **CBE** - Commercial Bank of Ethiopia
- **MPesa** - Mobile money (East Africa)
- **HelloCash** - Mobile payment service
- **Abyssinia** - Bank
- **Awash** - Bank
- **Dashen** - Bank
- **Bunna** - Bank
- **Amhara** - Bank
- **Berhan** - Bank
- **ZamZam** - Bank
- **Yimlu** - Bank

---

## 🔐 Authentication

All endpoints (except webhooks) require Bearer token authentication:

```
Authorization: Bearer <JWT_TOKEN>
```

Token should include:
- `id` - User ID
- `type` - User type (passenger, admin, driver)
- `phone` or `phoneNumber` or `mobile` - User phone number

---

## 📝 Rate Limiting

Recommended rate limits:

- **Wallet Topup:** 10 requests per minute per user
- **Payment Creation:** 5 requests per minute per user
- **Webhook:** No limit (from Santimpay servers)

---

**Last Updated:** 2024
**Version:** 1.0.0
