# Santimpay Integration Guide

Complete step-by-step guide to integrate Santimpay payment processing into your project.

## 📋 Prerequisites

- Node.js 14+ 
- Express.js 4.x or 5.x
- MySQL/PostgreSQL database
- Sequelize ORM
- Santimpay merchant account with API credentials

## 🔧 Step 1: Install Dependencies

```bash
npm install axios dotenv sequelize mysql2
```

### Optional Dependencies (for production)
```bash
npm install helmet express-rate-limit compression
```

## 📁 Step 2: Project Structure Setup

Create the following directory structure in your project:

```
your-project/
├── utils/
│   └── santimpay.js
├── controllers/
│   ├── paymentController.js
│   ├── walletController.js
│   └── subscriptionPaymentController.js
├── routes/
│   ├── paymentRoutes.js
│   ├── walletRoutes.js
│   └── webhookRoutes.js
├── models/
│   ├── walletModel.js
│   ├── transactionModel.js
│   └── paymentModel.js
├── middleware/
│   └── auth.js (existing authorization middleware)
├── config/
│   └── dbconfig.js (existing database config)
└── .env
```

## 🔐 Step 3: Environment Configuration

### Create `.env` file

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_NAME=your_database
DB_USER=your_db_user
DB_PASSWORD=your_db_password

# JWT Configuration
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=7d

# Santimpay Configuration
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
GATEWAY_MERCHANT_ID=your-merchant-id-here

# Private Key Configuration (choose ONE)
# Option 1: Direct PEM (development)
PRIVATE_KEY_IN_PEM="-----BEGIN EC PRIVATE KEY-----
MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49
AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92X
dcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==
-----END EC PRIVATE KEY-----"

# Option 2: Base64 Encoded (production)
# PRIVATE_KEY_BASE64=MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49...

# Option 3: File Path (containerized)
# PRIVATE_KEY_PATH=/secrets/private-key.pem

# Webhook Configuration
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook
PUBLIC_BASE_URL=https://your-domain.com

# Debug Mode
WALLET_WEBHOOK_DEBUG=1
```

## 📊 Step 4: Database Setup

### Create Database Tables

```sql
-- Wallets Table
CREATE TABLE wallets (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  userId VARCHAR(36) NOT NULL UNIQUE,
  balance DECIMAL(10, 2) DEFAULT 0,
  lastTransactionAt TIMESTAMP NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transactions Table
CREATE TABLE transactions (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  refId VARCHAR(255) UNIQUE,
  txnId VARCHAR(255),
  userId VARCHAR(36) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  type ENUM('credit', 'debit') NOT NULL,
  method VARCHAR(50) DEFAULT 'santimpay',
  status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  msisdn VARCHAR(20),
  walletId VARCHAR(36),
  metadata JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (walletId) REFERENCES wallets(id) ON DELETE SET NULL
);

-- Payments Table (if not exists)
CREATE TABLE contract_payments (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  subscription_id VARCHAR(36),
  contract_id VARCHAR(36),
  passenger_id VARCHAR(36) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  due_date DATE NOT NULL,
  receipt_image VARCHAR(255),
  transaction_reference VARCHAR(255),
  status ENUM('SUCCESS', 'FAILED', 'PENDING') DEFAULT 'PENDING',
  admin_approved BOOLEAN DEFAULT FALSE,
  approved_by VARCHAR(36),
  approved_at TIMESTAMP NULL,
  rejection_reason TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_transactions_userId ON transactions(userId);
CREATE INDEX idx_transactions_txnId ON transactions(txnId);
CREATE INDEX idx_transactions_refId ON transactions(refId);
CREATE INDEX idx_wallets_userId ON wallets(userId);
CREATE INDEX idx_payments_subscription_id ON contract_payments(subscription_id);
CREATE INDEX idx_payments_passenger_id ON contract_payments(passenger_id);
```

## 🗂️ Step 5: Create Models

### Wallet Model (`models/walletModel.js`)

```javascript
const { sequelize } = require("../config/dbconfig");
const { DataTypes } = require("sequelize");

const Wallet = sequelize.define(
  "Wallet",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
      unique: true,
    },
    balance: {
      type: DataTypes.DECIMAL(10, 2),
      defaultValue: 0,
    },
    lastTransactionAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: "wallets",
    timestamps: true,
  }
);

module.exports = Wallet;
```

### Transaction Model (`models/transactionModel.js`)

```javascript
const { sequelize } = require("../config/dbconfig");
const { DataTypes } = require("sequelize");

const Transaction = sequelize.define(
  "Transaction",
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    refId: {
      type: DataTypes.STRING(255),
      unique: true,
      allowNull: true,
    },
    txnId: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    },
    type: {
      type: DataTypes.ENUM("credit", "debit"),
      allowNull: false,
    },
    method: {
      type: DataTypes.STRING(50),
      defaultValue: "santimpay",
    },
    status: {
      type: DataTypes.ENUM("pending", "success", "failed"),
      defaultValue: "pending",
    },
    msisdn: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    walletId: {
      type: DataTypes.UUID,
      allowNull: true,
      references: { model: "wallets", key: "id" },
      onDelete: "SET NULL",
    },
    metadata: {
      type: DataTypes.JSON,
      allowNull: true,
    },
  },
  {
    tableName: "transactions",
    timestamps: true,
  }
);

module.exports = Transaction;
```

## 🔌 Step 6: Copy Integration Files

Copy the following files from the extraction package to your project:

1. **`utils/santimpay.js`** - Core SDK
2. **`controllers/walletController.js`** - Wallet operations
3. **`controllers/paymentController.js`** - Payment management
4. **`routes/walletRoutes.js`** - Wallet endpoints
5. **`routes/paymentRoutes.js`** - Payment endpoints
6. **`routes/webhookRoutes.js`** - Webhook handlers

## 🚀 Step 7: Mount Routes in Express App

### Update your main `index.js` or `app.js`

```javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Import routes
const walletRoutes = require('./routes/walletRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const webhookRoutes = require('./routes/webhookRoutes');

// Mount routes
app.use('/api/wallet', walletRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/webhooks', webhookRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
```

## 🧪 Step 8: Test the Integration

### Test 1: Wallet Topup

```bash
curl -X POST http://localhost:5000/api/wallet/topup \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 100,
    "paymentMethod": "Telebirr",
    "reason": "Test topup"
  }'
```

Expected Response:
```json
{
  "message": "Topup initiated",
  "transactionId": "uuid-here",
  "gatewayTxnId": "gateway-txn-id"
}
```

### Test 2: Get Wallet Balance

```bash
curl -X GET http://localhost:5000/api/wallet/balance \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Test 3: Simulate Webhook

```bash
curl -X POST http://localhost:5000/api/wallet/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "TxnId": "gateway-txn-id",
    "Status": "COMPLETED",
    "amount": 100,
    "msisdn": "+251911223344",
    "thirdPartyId": "your-transaction-id"
  }'
```

## 🔄 Step 9: Implement Authorization Middleware

Ensure your auth middleware is properly configured:

```javascript
// middleware/auth.js
const jwt = require('jsonwebtoken');

exports.authorize = (...roles) => {
  return (req, res, next) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      if (!token) {
        return res.status(401).json({ message: 'No token provided' });
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = decoded;

      if (roles.length && !roles.includes(decoded.type)) {
        return res.status(403).json({ message: 'Access denied' });
      }

      next();
    } catch (error) {
      res.status(401).json({ message: 'Invalid token' });
    }
  };
};
```

## 📱 Step 10: Phone Number Validation

The integration includes Ethiopian phone number validation. Ensure phone numbers are in format:

- **Valid formats:**
  - `+251911223344`
  - `0911223344` (converted to +251911223344)
  - `911223344` (converted to +251911223344)

- **Invalid formats:**
  - `+1234567890` (non-Ethiopian)
  - `123456` (too short)
  - `abc123` (non-numeric)

## 🔐 Step 11: Security Considerations

### 1. **Private Key Management**

Never commit private keys to version control:

```bash
# Add to .gitignore
.env
private-key.pem
*.pem
```

### 2. **HTTPS Only**

Ensure webhook URL uses HTTPS:

```env
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook
```

### 3. **Rate Limiting** (Optional)

```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/wallet/topup', limiter);
```

### 4. **Input Validation**

Always validate user input:

```javascript
if (!amount || amount <= 0) {
  return res.status(400).json({ message: 'Invalid amount' });
}

if (!paymentMethod || paymentMethod.trim() === '') {
  return res.status(400).json({ message: 'Payment method required' });
}
```

## 📊 Step 12: Monitoring & Logging

### Enable Debug Logging

```env
WALLET_WEBHOOK_DEBUG=1
```

### Monitor Logs

```bash
# Watch logs in real-time
tail -f logs/app.log

# Search for errors
grep -i error logs/app.log

# Search for webhook events
grep webhook logs/app.log
```

## ✅ Verification Checklist

- [ ] All dependencies installed
- [ ] Environment variables configured
- [ ] Database tables created
- [ ] Models defined
- [ ] Routes mounted
- [ ] Authorization middleware working
- [ ] Wallet topup tested
- [ ] Webhook endpoint accessible
- [ ] Private key properly configured
- [ ] Phone number validation working
- [ ] Error handling in place
- [ ] Logging enabled

## 🐛 Troubleshooting

### Issue: "Missing PRIVATE_KEY"

**Solution:** Ensure one of these is set in `.env`:
- `PRIVATE_KEY_IN_PEM`
- `PRIVATE_KEY_BASE64`
- `PRIVATE_KEY_PATH`

### Issue: "Invalid phone format"

**Solution:** Phone must be Ethiopian format `+2519XXXXXXXX`

### Issue: "Webhook not matching transaction"

**Solution:** Ensure `thirdPartyId` or `txnId` in webhook matches transaction record

### Issue: "GATEWAY_MERCHANT_ID not configured"

**Solution:** Add `GATEWAY_MERCHANT_ID` to `.env`

## 📚 Next Steps

1. Read **API_REFERENCE.md** for complete endpoint documentation
2. Review **WORKFLOW_DIAGRAM.md** for visual workflows
3. Check **examples/** folder for code samples
4. Test all endpoints thoroughly
5. Deploy to staging environment
6. Monitor logs and transactions
7. Deploy to production

## 🤝 Support

For issues:
1. Check the troubleshooting section above
2. Enable `WALLET_WEBHOOK_DEBUG=1` for detailed logs
3. Verify all environment variables are set
4. Check database tables exist
5. Ensure phone numbers are in correct format

---

**Last Updated:** 2024
**Version:** 1.0.0
