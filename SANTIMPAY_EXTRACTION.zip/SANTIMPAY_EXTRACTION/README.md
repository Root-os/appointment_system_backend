# Santimpay Payment Integration Package

This package contains a complete, production-ready Santimpay payment integration extracted from the Contract Ride Service. It includes all utilities, controllers, routes, models, and comprehensive documentation.

## 📦 Package Contents

```
SANTIMPAY_EXTRACTION/
├── README.md                          # This file
├── INTEGRATION_GUIDE.md               # Step-by-step integration guide
├── API_REFERENCE.md                   # Complete API documentation
├── WORKFLOW_DIAGRAM.md                # Visual workflow documentation
├── ENVIRONMENT_SETUP.md               # Environment configuration guide
│
├── utils/
│   └── santimpay.js                   # Core Santimpay SDK
│
├── controllers/
│   ├── paymentController.js           # Payment management
│   ├── walletController.js            # Wallet & topup operations
│   └── subscriptionPaymentController.js # Subscription payment handling
│
├── routes/
│   ├── paymentRoutes.js               # Payment endpoints
│   ├── walletRoutes.js                # Wallet endpoints
│   └── webhookRoutes.js               # Webhook handlers
│
├── models/
│   ├── paymentModel.js                # Payment schema
│   ├── walletModel.js                 # Wallet schema
│   ├── transactionModel.js            # Transaction schema
│   └── subscriptionModel.js           # Subscription schema (reference)
│
├── middleware/
│   └── santimpayMiddleware.js         # Payment-specific middleware
│
└── examples/
    ├── .env.example                   # Environment variables template
    ├── payment-flow.js                # Complete payment flow example
    └── webhook-handler.js             # Webhook handling example
```

## 🚀 Quick Start

### 1. **Copy Files to Your Project**

```bash
# Copy all integration files to your project
cp -r SANTIMPAY_EXTRACTION/utils/* your-project/utils/
cp -r SANTIMPAY_EXTRACTION/controllers/* your-project/controllers/
cp -r SANTIMPAY_EXTRACTION/routes/* your-project/routes/
cp -r SANTIMPAY_EXTRACTION/models/* your-project/models/
cp -r SANTIMPAY_EXTRACTION/middleware/* your-project/middleware/
```

### 2. **Install Dependencies**

```bash
npm install axios dotenv sequelize mysql2
```

### 3. **Configure Environment Variables**

Copy `.env.example` to `.env` and fill in your Santimpay credentials:

```env
# Santimpay Configuration
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
GATEWAY_MERCHANT_ID=your-merchant-id
PRIVATE_KEY_IN_PEM="-----BEGIN EC PRIVATE KEY-----\n...\n-----END EC PRIVATE KEY-----"
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook
```

### 4. **Mount Routes in Your Express App**

```javascript
const express = require('express');
const app = express();

// Mount payment routes
const paymentRoutes = require('./routes/paymentRoutes');
const walletRoutes = require('./routes/walletRoutes');
const webhookRoutes = require('./routes/webhookRoutes');

app.use('/api/payments', paymentRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/webhooks', webhookRoutes);
```

## 🔄 Payment Workflows

### **1. Wallet Topup Flow**
```
User → POST /api/wallet/topup
  ↓
Create pending transaction
  ↓
Call Santimpay directPayment API
  ↓
Return transaction ID to user
  ↓
Santimpay → POST /api/wallet/webhook (callback)
  ↓
Update transaction status
  ↓
Update wallet balance (if success)
```

### **2. Subscription Payment Flow**
```
Passenger → POST /api/subscription/:id/payment
  ↓
Validate subscription & phone number
  ↓
Create pending wallet transaction
  ↓
Call Santimpay directPayment API
  ↓
Store payment reference
  ↓
Santimpay → POST /api/wallet/webhook (callback)
  ↓
Update subscription payment_status
  ↓
Update wallet transaction & balance
```

### **3. Direct Payment Flow**
```
User → POST /api/payments/direct
  ↓
Validate amount & payment method
  ↓
Call Santimpay directPayment API
  ↓
Return gateway transaction ID
  ↓
Santimpay → POST /api/wallet/webhook (callback)
  ↓
Update transaction status
```

## 📊 Key Features

### ✅ **Core Capabilities**
- **ES256 JWT Signing** - Secure request authentication
- **Multiple Payment Methods** - Telebirr, CBE, MPesa, HelloCash, etc.
- **Wallet Management** - Balance tracking and topup
- **Transaction History** - Complete audit trail
- **Webhook Handling** - Automatic status updates
- **Error Handling** - Comprehensive error management

### ✅ **Security Features**
- **Private Key Management** - Multiple configuration options (PEM, Base64, File path)
- **Phone Number Validation** - Ethiopian MSISDN format validation
- **Idempotency** - Prevents duplicate wallet mutations
- **Authorization** - Role-based access control
- **Webhook Verification** - Transaction matching and validation

### ✅ **Developer Experience**
- **Structured Logging** - Console logs for debugging (can be toggled)
- **Error Messages** - Clear, actionable error responses
- **Flexible Configuration** - Environment-based setup
- **Modular Design** - Easy to extend and customize

## 🔐 Environment Configuration

### **Private Key Options** (in priority order)

1. **Direct PEM** (Recommended for development)
```env
PRIVATE_KEY_IN_PEM="-----BEGIN EC PRIVATE KEY-----\n...\n-----END EC PRIVATE KEY-----"
```

2. **Base64 Encoded** (Recommended for production)
```env
PRIVATE_KEY_BASE64=MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49...
```

3. **File Path** (Recommended for containerized deployments)
```env
PRIVATE_KEY_PATH=/secrets/private-key.pem
```

## 📱 Payment Methods Supported

The integration supports the following payment methods:

- **Telebirr** - Ethiopian mobile money
- **CBE** - Commercial Bank of Ethiopia
- **MPesa** - Mobile money (East Africa)
- **HelloCash** - Mobile payment service
- **Abyssinia** - Bank
- **Awash** - Bank
- **Dashen** - Bank
- **Bunna** - Bank
- **Amhara** - Bank
- **Berhan** - Bank
- **ZamZam** - Bank
- **Yimlu** - Bank

## 🔌 API Endpoints

### **Wallet Endpoints**

```http
POST /api/wallet/topup
  - Initiate wallet topup
  - Body: { amount, paymentMethod, reason }

POST /api/wallet/webhook
  - Santimpay callback endpoint (public)
  - Handles payment status updates

GET /api/wallet/balance
  - Get current wallet balance

GET /api/wallet/transactions
  - List user's transactions

GET /api/wallet/admin/balances
  - Admin: List all user balances

GET /api/wallet/admin/transactions
  - Admin: List all transactions
```

### **Payment Endpoints**

```http
POST /api/payments
  - Create payment record
  - Body: { subscription_id, amount, payment_method, transaction_reference }

GET /api/payments
  - List payments (admin/passenger)

GET /api/payments/pending
  - Admin: List pending payments

PATCH /api/payments/:id/approve
  - Admin: Approve payment

PATCH /api/payments/:id/reject
  - Admin: Reject payment with reason

GET /api/payments/:id
  - Get payment details

PUT /api/payments/:id
  - Update payment

DELETE /api/payments/:id
  - Delete payment
```

### **Subscription Payment Endpoints**

```http
POST /api/subscription/:id/payment
  - Process subscription payment
  - Body: { payment_method, payment_option_id (optional) }

POST /api/subscription/webhook
  - Subscription payment webhook (public)
  - Handles subscription payment status updates
```

## 🧪 Testing

### **Test Wallet Topup**

```bash
curl -X POST http://localhost:5000/api/wallet/topup \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 100,
    "paymentMethod": "Telebirr",
    "reason": "Wallet topup"
  }'
```

### **Test Subscription Payment**

```bash
curl -X POST http://localhost:5000/api/subscription/SUBSCRIPTION_ID/payment \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "payment_method": "Telebirr"
  }'
```

### **Simulate Webhook**

```bash
curl -X POST http://localhost:5000/api/wallet/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "TxnId": "gateway-txn-id",
    "Status": "COMPLETED",
    "amount": 100,
    "msisdn": "+251911223344",
    "thirdPartyId": "your-transaction-id"
  }'
```

## 📋 Database Schema

### **Wallet Table**
```sql
CREATE TABLE wallets (
  id UUID PRIMARY KEY DEFAULT uuid(),
  userId UUID NOT NULL UNIQUE,
  balance DECIMAL(10, 2) DEFAULT 0,
  lastTransactionAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### **Transaction Table**
```sql
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT uuid(),
  refId VARCHAR(255) UNIQUE,
  txnId VARCHAR(255),
  userId UUID NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  type ENUM('credit', 'debit') NOT NULL,
  method VARCHAR(50) DEFAULT 'santimpay',
  status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  msisdn VARCHAR(20),
  walletId UUID,
  metadata JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (walletId) REFERENCES wallets(id)
);
```

### **Payment Table**
```sql
CREATE TABLE contract_payments (
  id UUID PRIMARY KEY DEFAULT uuid(),
  subscription_id UUID,
  contract_id UUID,
  passenger_id UUID NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  due_date DATE NOT NULL,
  receipt_image VARCHAR(255),
  transaction_reference VARCHAR(255),
  status ENUM('SUCCESS', 'FAILED', 'PENDING') DEFAULT 'PENDING',
  admin_approved BOOLEAN DEFAULT FALSE,
  approved_by UUID,
  approved_at TIMESTAMP,
  rejection_reason TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🐛 Debugging

### **Enable Debug Logging**

```env
WALLET_WEBHOOK_DEBUG=1
```

This will log:
- Webhook received data
- Transaction matching
- Wallet mutations
- Error details

### **Common Issues**

| Issue | Solution |
|-------|----------|
| "Missing PRIVATE_KEY" | Ensure one of PRIVATE_KEY_IN_PEM, PRIVATE_KEY_BASE64, or PRIVATE_KEY_PATH is set |
| "Invalid phone format" | Phone must be in format +2519XXXXXXXX |
| "Webhook not matching" | Ensure thirdPartyId or txnId matches transaction record |
| "Payment method not recognized" | Check supported payment methods list |

## 📚 Additional Resources

- **INTEGRATION_GUIDE.md** - Detailed step-by-step integration
- **API_REFERENCE.md** - Complete API documentation
- **WORKFLOW_DIAGRAM.md** - Visual workflow diagrams
- **ENVIRONMENT_SETUP.md** - Environment configuration details

## 🤝 Support

For issues or questions:

1. Check the **Debugging** section above
2. Review **INTEGRATION_GUIDE.md** for detailed setup
3. Check **API_REFERENCE.md** for endpoint details
4. Enable **WALLET_WEBHOOK_DEBUG=1** for detailed logs

## 📝 License

This integration package is extracted from the Contract Ride Service and follows the same license terms.

## ✨ Version History

- **v1.0.0** - Initial extraction from Contract Ride Service
  - Core Santimpay SDK
  - Wallet management
  - Subscription payments
  - Payment approval workflow
  - Webhook handling
  - Complete documentation
