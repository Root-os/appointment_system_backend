/**
 * Complete Payment Flow Example
 * 
 * This file demonstrates the complete flow of a wallet topup payment
 * from initiation to webhook callback and wallet balance update.
 */

const express = require('express');
const app = express();
app.use(express.json());

// ============================================
// 1. WALLET TOPUP INITIATION
// ============================================

/**
 * Example: User initiates a wallet topup
 * 
 * POST /api/wallet/topup
 * Authorization: Bearer <JWT_TOKEN>
 * 
 * Request Body:
 */
const topupRequest = {
  amount: 100,
  paymentMethod: "Telebirr",
  reason: "Wallet topup for subscription"
};

/**
 * Expected Response (202 Accepted):
 */
const topupResponse = {
  message: "Topup initiated",
  transactionId: "550e8400-e29b-41d4-a716-446655440000",
  gatewayTxnId: "GW-TXN-123456789"
};

// ============================================
// 2. GATEWAY PROCESSING
// ============================================

/**
 * At this point:
 * - Transaction created in DB with status: "pending"
 * - Santimpay gateway processes the payment
 * - User completes payment on their phone
 * - Santimpay prepares webhook callback
 */

// ============================================
// 3. WEBHOOK CALLBACK
// ============================================

/**
 * Santimpay calls our webhook endpoint with payment status
 * 
 * POST /api/wallet/webhook
 * 
 * Request Body (from Santimpay):
 */
const webhookPayload = {
  TxnId: "GW-TXN-123456789",
  Status: "COMPLETED",
  amount: 100,
  msisdn: "+251911223344",
  thirdPartyId: "550e8400-e29b-41d4-a716-446655440000",
  commission: 5,
  totalAmount: 105,
  reason: "Wallet topup",
  created_at: "2024-01-15T10:30:00Z",
  merId: "merchant-123",
  merName: "Contract Ride Service"
};

/**
 * Webhook Processing Steps:
 * 1. Extract thirdPartyId (our transaction ID)
 * 2. Find transaction in database
 * 3. Normalize status (COMPLETED → "success")
 * 4. Update transaction status
 * 5. Check idempotency (prevent duplicate mutations)
 * 6. Update wallet balance
 * 7. Return acknowledgment
 */

/**
 * Webhook Response (200 OK):
 */
const webhookResponse = {
  ok: true,
  txnId: "GW-TXN-123456789",
  refId: "550e8400-e29b-41d4-a716-446655440000",
  thirdPartyId: "550e8400-e29b-41d4-a716-446655440000",
  status: "COMPLETED",
  amount: 100,
  currency: "ETB",
  msisdn: "+251911223344",
  updatedAt: "2024-01-15T10:30:00Z"
};

// ============================================
// 4. DATABASE STATE AFTER WEBHOOK
// ============================================

/**
 * Transaction Record (Updated):
 */
const transactionAfterWebhook = {
  id: "550e8400-e29b-41d4-a716-446655440000",
  refId: "550e8400-e29b-41d4-a716-446655440000",
  txnId: "GW-TXN-123456789",
  userId: "user-123",
  amount: 100,
  type: "credit",
  method: "santimpay",
  status: "success",  // Updated from "pending"
  msisdn: "+251911223344",
  walletId: "wallet-123",
  metadata: {
    reason: "Wallet topup",
    gatewayResponse: webhookPayload,
    webhook: webhookPayload,
    paymentVia: "Telebirr"
  },
  createdAt: "2024-01-15T10:25:00Z",
  updatedAt: "2024-01-15T10:30:00Z"
};

/**
 * Wallet Record (Updated):
 */
const walletAfterWebhook = {
  id: "wallet-123",
  userId: "user-123",
  balance: 100,  // Updated: added topup amount
  lastTransactionAt: "2024-01-15T10:30:00Z",
  createdAt: "2024-01-15T08:00:00Z",
  updatedAt: "2024-01-15T10:30:00Z"
};

// ============================================
// 5. COMPLETE FLOW EXAMPLE
// ============================================

/**
 * Full workflow with all steps:
 */
const completeFlowExample = {
  step1_initiation: {
    endpoint: "POST /api/wallet/topup",
    request: topupRequest,
    response: topupResponse,
    dbChanges: {
      transaction: {
        status: "pending",
        refId: "550e8400-e29b-41d4-a716-446655440000",
        txnId: "GW-TXN-123456789"
      },
      wallet: {
        created: true
      }
    }
  },
  
  step2_gateway_processing: {
    description: "Santimpay processes payment",
    duration: "1-5 minutes",
    userAction: "Complete payment on phone"
  },
  
  step3_webhook_callback: {
    endpoint: "POST /api/wallet/webhook",
    request: webhookPayload,
    response: webhookResponse,
    dbChanges: {
      transaction: {
        status: "success",
        metadata: "Updated with webhook data"
      },
      wallet: {
        balance: 100,
        lastTransactionAt: "2024-01-15T10:30:00Z"
      }
    }
  },
  
  step4_verification: {
    endpoint: "GET /api/wallet/balance",
    response: {
      balance: 100,
      currency: "ETB",
      userId: "user-123",
      lastTransactionAt: "2024-01-15T10:30:00Z"
    }
  }
};

// ============================================
// 6. ERROR SCENARIOS
// ============================================

/**
 * Scenario 1: Invalid Phone Format
 */
const errorScenario1 = {
  request: {
    amount: 100,
    paymentMethod: "Telebirr"
  },
  response: {
    status: 400,
    message: "Invalid phone format in token. Required: +2519XXXXXXXX"
  }
};

/**
 * Scenario 2: Gateway Error
 */
const errorScenario2 = {
  request: {
    amount: 100,
    paymentMethod: "Telebirr"
  },
  response: {
    status: 502,
    message: "Payment initiation failed: Gateway error",
    gateway_status: 500,
    gateway_response: {
      error: "Service temporarily unavailable"
    }
  },
  dbChanges: {
    transaction: {
      status: "failed",
      metadata: {
        gatewayError: "Service temporarily unavailable"
      }
    }
  }
};

/**
 * Scenario 3: Payment Failed at Gateway
 */
const errorScenario3 = {
  webhookPayload: {
    TxnId: "GW-TXN-123456789",
    Status: "FAILED",
    amount: 100,
    msisdn: "+251911223344",
    thirdPartyId: "550e8400-e29b-41d4-a716-446655440000",
    reason: "Insufficient funds"
  },
  dbChanges: {
    transaction: {
      status: "failed",
      metadata: {
        webhookStatus: "FAILED",
        reason: "Insufficient funds"
      }
    },
    wallet: {
      balance: 0  // Not updated
    }
  }
};

/**
 * Scenario 4: Idempotent Webhook (Duplicate Callback)
 */
const errorScenario4 = {
  description: "Santimpay sends webhook twice (network retry)",
  firstCall: {
    transactionBefore: { status: "pending" },
    transactionAfter: { status: "success" },
    walletBefore: { balance: 0 },
    walletAfter: { balance: 100 }
  },
  secondCall: {
    transactionBefore: { status: "success" },
    transactionAfter: { status: "success" },  // No change
    walletBefore: { balance: 100 },
    walletAfter: { balance: 100 }  // No change (idempotent)
  }
};

// ============================================
// 7. TESTING THE FLOW
// ============================================

/**
 * Test with cURL:
 */
const curlExamples = {
  step1_topup: `
curl -X POST http://localhost:5000/api/wallet/topup \\
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "amount": 100,
    "paymentMethod": "Telebirr",
    "reason": "Wallet topup"
  }'
  `,
  
  step2_check_balance: `
curl -X GET http://localhost:5000/api/wallet/balance \\
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  `,
  
  step3_simulate_webhook: `
curl -X POST http://localhost:5000/api/wallet/webhook \\
  -H "Content-Type: application/json" \\
  -d '{
    "TxnId": "GW-TXN-123456789",
    "Status": "COMPLETED",
    "amount": 100,
    "msisdn": "+251911223344",
    "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000"
  }'
  `,
  
  step4_verify_balance: `
curl -X GET http://localhost:5000/api/wallet/balance \\
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  `
};

// ============================================
// 8. TRANSACTION STATES
// ============================================

/**
 * Possible transaction states and transitions:
 */
const transactionStates = {
  pending: {
    description: "Payment initiated, awaiting webhook",
    canTransitionTo: ["success", "failed"],
    walletUpdated: false
  },
  success: {
    description: "Payment completed successfully",
    canTransitionTo: [],  // Final state
    walletUpdated: true
  },
  failed: {
    description: "Payment failed",
    canTransitionTo: [],  // Final state
    walletUpdated: false
  }
};

// ============================================
// 9. PAYMENT METHOD NORMALIZATION
// ============================================

/**
 * Payment methods are normalized to standard names:
 */
const paymentMethodNormalization = {
  input: ["telebirr", "tele", "tele-birr", "Telebirr", "TELEBIRR"],
  normalized: "Telebirr",
  
  cbeExamples: ["cbe", "CBE", "cbe-birr", "Commercial Bank of Ethiopia"],
  cbENormalized: "CBE",
  
  mobileMoneyExamples: ["mobile_money", "mobile money", "momo"],
  mobileMoneyNormalized: "HelloCash"
};

// ============================================
// 10. PHONE NUMBER NORMALIZATION
// ============================================

/**
 * Phone numbers are normalized to +2519XXXXXXXX format:
 */
const phoneNormalization = {
  examples: {
    "+251911223344": "+251911223344",  // Already correct
    "0911223344": "+251911223344",     // Leading 0 converted
    "911223344": "+251911223344",      // No prefix added
    "+251 911 223 344": "+251911223344" // Spaces removed
  },
  invalid: {
    "+1234567890": null,  // Non-Ethiopian
    "123456": null,       // Too short
    "abc123": null        // Non-numeric
  }
};

module.exports = {
  topupRequest,
  topupResponse,
  webhookPayload,
  webhookResponse,
  transactionAfterWebhook,
  walletAfterWebhook,
  completeFlowExample,
  errorScenario1,
  errorScenario2,
  errorScenario3,
  errorScenario4,
  curlExamples,
  transactionStates,
  paymentMethodNormalization,
  phoneNormalization
};
