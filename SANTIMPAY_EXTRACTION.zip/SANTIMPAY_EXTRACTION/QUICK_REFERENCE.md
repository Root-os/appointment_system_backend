# Santimpay Integration - Quick Reference Card

One-page reference for common tasks and commands.

## 🚀 Quick Start Commands

```bash
# 1. Copy files to your project
cp -r utils/* your-project/utils/
cp -r controllers/* your-project/controllers/
cp -r routes/* your-project/routes/

# 2. Install dependencies
npm install axios dotenv sequelize mysql2

# 3. Setup environment
cp examples/.env.example .env
# Edit .env with your credentials

# 4. Create database tables
mysql -u root -p < database-setup.sql

# 5. Start server
npm run dev
```

---

## 🔑 Environment Variables Checklist

```env
# Required
GATEWAY_MERCHANT_ID=your-id
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook

# Private Key (choose ONE)
PRIVATE_KEY_IN_PEM="..."        # Development
PRIVATE_KEY_BASE64="..."        # Production
PRIVATE_KEY_PATH=/path/to/key   # Containerized

# Database
DB_HOST=localhost
DB_NAME=database
DB_USER=user
DB_PASSWORD=password

# JWT
JWT_SECRET=your-secret
JWT_EXPIRES_IN=7d
```

---

## 📱 API Endpoints Quick Reference

### Wallet Endpoints
```
POST   /api/wallet/topup              # Initiate topup
GET    /api/wallet/balance            # Get balance
GET    /api/wallet/transactions       # List transactions
POST   /api/wallet/webhook            # Webhook callback
GET    /api/wallet/admin/balances     # Admin: all balances
GET    /api/wallet/admin/transactions # Admin: all transactions
```

### Payment Endpoints
```
POST   /api/payments                  # Create payment
GET    /api/payments                  # List payments
GET    /api/payments/:id              # Get payment
PUT    /api/payments/:id              # Update payment
DELETE /api/payments/:id              # Delete payment
GET    /api/payments/pending          # Admin: pending
PATCH  /api/payments/:id/approve      # Admin: approve
PATCH  /api/payments/:id/reject       # Admin: reject
```

### Subscription Endpoints
```
POST   /api/subscription/:id/payment  # Process payment
POST   /api/subscription/webhook      # Webhook callback
```

---

## 🧪 Testing Commands

```bash
# Test topup
curl -X POST http://localhost:5000/api/wallet/topup \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"amount": 100, "paymentMethod": "Telebirr"}'

# Check balance
curl -X GET http://localhost:5000/api/wallet/balance \
  -H "Authorization: Bearer TOKEN"

# Simulate webhook
curl -X POST http://localhost:5000/api/wallet/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "TxnId": "GW-TXN-123",
    "Status": "COMPLETED",
    "amount": 100,
    "msisdn": "+251911223344",
    "thirdPartyId": "550e8400-e29b-41d4-a716-446655440000"
  }'

# List transactions
curl -X GET http://localhost:5000/api/wallet/transactions \
  -H "Authorization: Bearer TOKEN"
```

---

## 💾 Database Quick Setup

```sql
-- Wallets
CREATE TABLE wallets (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  userId VARCHAR(36) UNIQUE NOT NULL,
  balance DECIMAL(10, 2) DEFAULT 0,
  lastTransactionAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transactions
CREATE TABLE transactions (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  refId VARCHAR(255) UNIQUE,
  txnId VARCHAR(255),
  userId VARCHAR(36) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  type ENUM('credit', 'debit'),
  method VARCHAR(50) DEFAULT 'santimpay',
  status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  msisdn VARCHAR(20),
  walletId VARCHAR(36),
  metadata JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (walletId) REFERENCES wallets(id)
);

-- Payments
CREATE TABLE contract_payments (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  subscription_id VARCHAR(36),
  contract_id VARCHAR(36),
  passenger_id VARCHAR(36) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  status ENUM('SUCCESS', 'FAILED', 'PENDING') DEFAULT 'PENDING',
  admin_approved BOOLEAN DEFAULT FALSE,
  approved_by VARCHAR(36),
  approved_at TIMESTAMP,
  rejection_reason TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_transactions_userId ON transactions(userId);
CREATE INDEX idx_transactions_txnId ON transactions(txnId);
CREATE INDEX idx_wallets_userId ON wallets(userId);
```

---

## 🔐 Security Checklist

- [ ] Private key NOT in version control
- [ ] `.env` added to `.gitignore`
- [ ] HTTPS enabled for webhook URL
- [ ] Phone validation implemented
- [ ] Authorization middleware active
- [ ] Rate limiting configured
- [ ] Webhook signature verification (optional)
- [ ] Database backups enabled
- [ ] Logs monitored
- [ ] Error handling in place

---

## 📊 Payment Methods

```
Telebirr, CBE, MPesa, HelloCash, 
Abyssinia, Awash, Dashen, Bunna, 
Amhara, Berhan, ZamZam, Yimlu
```

---

## 🔄 Status Transitions

```
Transaction:
pending → success ✓
pending → failed ✗

Subscription:
PENDING → ACTIVE (payment approved)
PENDING → PENDING (payment rejected)

Payment:
PENDING → SUCCESS (approved)
PENDING → FAILED (rejected)
```

---

## 📞 Phone Format

```
Valid:
  +251911223344
  0911223344 → +251911223344
  911223344 → +251911223344

Invalid:
  +1234567890 (non-Ethiopian)
  123456 (too short)
  abc123 (non-numeric)
```

---

## 🐛 Troubleshooting Quick Fixes

| Issue | Solution |
|-------|----------|
| "Missing PRIVATE_KEY" | Set PRIVATE_KEY_IN_PEM, PRIVATE_KEY_BASE64, or PRIVATE_KEY_PATH |
| "Invalid phone format" | Phone must be +2519XXXXXXXX |
| "Webhook not matching" | Check thirdPartyId or txnId in database |
| "GATEWAY_MERCHANT_ID not configured" | Add to .env |
| "Database connection failed" | Check DB_HOST, DB_USER, DB_PASSWORD |
| "Payment method not recognized" | Check normalizePaymentMethod() function |

---

## 📈 Performance Tips

```javascript
// Enable indexes
CREATE INDEX idx_transactions_userId ON transactions(userId);
CREATE INDEX idx_transactions_txnId ON transactions(txnId);

// Cache payment methods
const paymentMethods = ['Telebirr', 'CBE', 'MPesa', ...];

// Batch webhook processing
Promise.all([updateTransaction, updateWallet]);

// Use connection pooling
const pool = mysql.createPool({...});
```

---

## 🎯 Integration Checklist

- [ ] Files copied
- [ ] Dependencies installed
- [ ] Environment configured
- [ ] Database tables created
- [ ] Routes mounted
- [ ] Authorization middleware active
- [ ] Phone validation working
- [ ] Wallet topup tested
- [ ] Webhook endpoint accessible
- [ ] Error handling verified
- [ ] Logging enabled
- [ ] Security checks passed

---

## 📚 Documentation Map

```
START HERE → README.md
    ↓
UNDERSTAND → WORKFLOW_DIAGRAM.md
    ↓
SETUP → INTEGRATION_GUIDE.md
    ↓
CONFIGURE → ENVIRONMENT_SETUP.md
    ↓
REFERENCE → API_REFERENCE.md
    ↓
TROUBLESHOOT → ENVIRONMENT_SETUP.md (Troubleshooting)
```

---

## 🚀 Deployment Commands

```bash
# Development
npm run dev

# Production (PM2)
pm2 start index.js --name "payment-service"

# Docker
docker build -t payment-service .
docker run -d --env-file .env payment-service

# Systemd
sudo systemctl start payment-service
```

---

## 📝 Common Response Formats

```json
// Success
{
  "success": true,
  "message": "Operation successful",
  "data": {}
}

// Error
{
  "success": false,
  "message": "Error description",
  "error": "error-code"
}

// Webhook
{
  "ok": true,
  "txnId": "...",
  "status": "COMPLETED"
}
```

---

## 🔗 Important Links

- **Santimpay:** https://santimpay.com/
- **Node.js:** https://nodejs.org/
- **Express:** https://expressjs.com/
- **Sequelize:** https://sequelize.org/
- **MySQL:** https://www.mysql.com/

---

## 📞 Support

- Check **ENVIRONMENT_SETUP.md** for troubleshooting
- Review **API_REFERENCE.md** for error codes
- See **examples/payment-flow.js** for code samples
- Read **WORKFLOW_DIAGRAM.md** for flow details

---

**Print this page for quick reference!**

Last Updated: 2024 | Version: 1.0.0
