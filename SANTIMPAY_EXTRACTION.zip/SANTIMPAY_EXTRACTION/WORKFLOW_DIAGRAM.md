# Santimpay Payment Integration - Workflow Diagrams

Visual representation of all payment workflows in the Santimpay integration.

## 📊 Table of Contents

1. [Wallet Topup Flow](#wallet-topup-flow)
2. [Subscription Payment Flow](#subscription-payment-flow)
3. [Direct Payment Flow](#direct-payment-flow)
4. [Payment Approval Flow](#payment-approval-flow)
5. [Webhook Processing Flow](#webhook-processing-flow)
6. [Transaction Status Flow](#transaction-status-flow)

---

## 💰 Wallet Topup Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    WALLET TOPUP WORKFLOW                        │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐
│ User/Client  │
└──────┬───────┘
       │
       │ POST /api/wallet/topup
       │ {amount, paymentMethod, reason}
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. VALIDATE REQUEST                                          │
│    - Check amount > 0                                        │
│    - Validate phone from token                               │
│    - Normalize phone to +2519XXXXXXXX format                 │
│    - Resolve payment method                                  │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ INVALID ──► Return 400 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. CREATE PENDING TRANSACTION                                │
│    - Generate transaction ID (UUID)                          │
│    - Create Transaction record                               │
│    - Status: "pending"                                       │
│    - Type: "credit"                                          │
│    - Method: "santimpay"                                     │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. CALL SANTIMPAY GATEWAY                                    │
│    - directPayment API                                       │
│    - Parameters:                                             │
│      • id: transaction ID                                    │
│      • amount: topup amount                                  │
│      • paymentMethod: normalized method                      │
│      • phoneNumber: normalized MSISDN                        │
│      • notifyUrl: webhook endpoint                           │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Update transaction status: "failed"
       │            Return 400 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. STORE GATEWAY RESPONSE                                    │
│    - Extract TxnId from gateway response                     │
│    - Update transaction with gateway TxnId                   │
│    - Store gateway response in metadata                      │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. RETURN TO CLIENT                                          │
│    - Status: 202 Accepted                                    │
│    - transactionId: our transaction ID                       │
│    - gatewayTxnId: Santimpay transaction ID                  │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. WAIT FOR WEBHOOK CALLBACK                                 │
│    - Santimpay processes payment                             │
│    - User completes payment on their phone                   │
│    - Santimpay calls webhook endpoint                        │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 7. WEBHOOK RECEIVED                                          │
│    - POST /api/wallet/webhook                                │
│    - Extract thirdPartyId (our transaction ID)               │
│    - Extract Status (COMPLETED, FAILED, etc.)                │
│    - Extract amount and other details                        │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 8. MATCH TRANSACTION                                         │
│    - Find transaction by refId (thirdPartyId)                │
│    - Fallback: Find by gateway TxnId                         │
│    - If not found: Return 200 OK (acknowledge)               │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ NOT FOUND ──► Return 200 OK
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 9. UPDATE TRANSACTION STATUS                                 │
│    - Map webhook status to transaction status                │
│    - COMPLETED/SUCCESS/APPROVED ──► "success"                │
│    - FAILED/CANCELLED/DECLINED ──► "failed"                  │
│    - Other ──► "pending"                                     │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 10. CHECK IDEMPOTENCY                                        │
│     - If transaction already in final state (success/failed)  │
│     - Skip wallet mutation                                    │
│     - Return 200 OK                                          │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ALREADY FINAL ──► Return 200 OK
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 11. UPDATE WALLET (if success)                               │
│     - Find or create wallet for user                         │
│     - Add amount to balance                                  │
│     - Update lastTransactionAt                               │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 12. ACKNOWLEDGE WEBHOOK                                      │
│     - Return 200 OK with transaction details                 │
│     - Santimpay stops retrying                               │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│ COMPLETE     │
│ Wallet       │
│ Updated ✓    │
└──────────────┘
```

---

## 🚗 Subscription Payment Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              SUBSCRIPTION PAYMENT WORKFLOW                       │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐
│ Passenger    │
└──────┬───────┘
       │
       │ POST /api/subscription/:id/payment
       │ {payment_method, payment_option_id}
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. VALIDATE SUBSCRIPTION                                     │
│    - Find subscription by ID                                 │
│    - Check ownership (passenger_id matches)                  │
│    - Check not already paid                                  │
│    - Extract final_fare amount                               │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ INVALID ──► Return 400/403/404 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. RESOLVE PAYMENT METHOD                                    │
│    Priority:                                                 │
│    1. payment_option_id from request                         │
│    2. payment_method from request                            │
│    3. User payment preference                                │
│    4. Default: Telebirr                                      │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. VALIDATE PHONE NUMBER                                     │
│    - Get from token (phone/phoneNumber/mobile)               │
│    - Fallback: Get from subscription data                    │
│    - Normalize to +2519XXXXXXXX format                       │
│    - Validate Ethiopian format                               │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ INVALID ──► Return 400 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. CREATE PENDING WALLET TRANSACTION                         │
│    - Generate transaction ID                                 │
│    - Find or create wallet                                   │
│    - Create Transaction record                               │
│    - Status: "pending"                                       │
│    - Type: "debit"                                           │
│    - Store subscription ID in metadata                       │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. CALL SANTIMPAY GATEWAY                                    │
│    - directPayment API                                       │
│    - Parameters:                                             │
│      • id: subscription ID                                   │
│      • amount: final_fare                                    │
│      • paymentMethod: normalized method                      │
│      • phoneNumber: normalized MSISDN                        │
│      • notifyUrl: webhook endpoint                           │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return 502 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. STORE PAYMENT REFERENCE                                   │
│    - Extract TxnId from gateway response                     │
│    - Update subscription.payment_reference                   │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 7. RETURN TO CLIENT                                          │
│    - Status: 200 OK                                          │
│    - subscription_id: subscription ID                        │
│    - gatewayTxnId: Santimpay transaction ID                  │
│    - amount: payment amount                                  │
│    - payment_method: method used                             │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 8. WAIT FOR WEBHOOK CALLBACK                                 │
│    - User completes payment                                  │
│    - Santimpay calls webhook                                 │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 9. WEBHOOK RECEIVED                                          │
│    - POST /api/subscription/webhook                          │
│    - Extract thirdPartyId (subscription ID)                  │
│    - Extract Status                                          │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 10. MATCH SUBSCRIPTION                                       │
│     - Find by thirdPartyId (subscription ID)                 │
│     - Fallback: Find by payment_reference (gateway TxnId)    │
│     - If not found: Return 200 OK                            │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ NOT FOUND ──► Return 200 OK
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 11. UPDATE SUBSCRIPTION STATUS                               │
│     - If success: payment_status = "PAID"                    │
│     - If failed: payment_status = "FAILED"                   │
│     - Store payment_reference (gateway TxnId)                │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 12. UPDATE WALLET TRANSACTION                                │
│     - Find transaction by subscription ID in metadata        │
│     - Update status (pending → success/failed)               │
│     - Store gateway response                                 │
│     - If success: deduct from wallet balance                 │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 13. ACKNOWLEDGE WEBHOOK                                      │
│     - Return 200 OK                                          │
│     - subscription_id                                        │
│     - status (PAID/FAILED)                                   │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│ COMPLETE     │
│ Subscription │
│ Payment ✓    │
└──────────────┘
```

---

## 💳 Direct Payment Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                  DIRECT PAYMENT WORKFLOW                        │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐
│ User/Client  │
└──────┬───────┘
       │
       │ POST /api/payments
       │ {subscription_id, amount, payment_method, ...}
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. VALIDATE REQUEST                                          │
│    - Check required fields                                   │
│    - Validate subscription exists                            │
│    - Check user ownership                                    │
│    - Validate amount                                         │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ INVALID ──► Return 400/403/404 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. CREATE PAYMENT RECORD                                     │
│    - Status: "PENDING"                                       │
│    - admin_approved: false                                   │
│    - Store all payment details                               │
│    - Handle file upload if present                           │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. RETURN TO CLIENT                                          │
│    - Status: 201 Created                                     │
│    - paymentId: payment record ID                            │
│    - Message: "Payment submitted for admin approval"         │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. ADMIN REVIEWS PAYMENT                                     │
│    - GET /api/payments/pending                               │
│    - Review payment details                                  │
│    - Check receipt/documentation                             │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ APPROVE ──────────────────┐
       │                            │
       ├─ REJECT ───────────────────┤
       │                            │
       ▼                            ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│ PATCH /approve           │  │ PATCH /reject            │
│ - Update status: SUCCESS │  │ - Update status: FAILED  │
│ - Set admin_approved     │  │ - Set rejection_reason   │
│ - Activate subscription  │  │ - Keep subscription      │
│ - Update wallet          │  │   PENDING                │
└──────────────────────────┘  └──────────────────────────┘
       │                            │
       ▼                            ▼
    COMPLETE                     COMPLETE
```

---

## ✅ Payment Approval Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              PAYMENT APPROVAL WORKFLOW                          │
└─────────────────────────────────────────────────────────────────┘

PENDING PAYMENT
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ Admin Reviews Payment                                        │
│ - Amount verification                                        │
│ - Receipt validation                                         │
│ - Transaction reference check                                │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ APPROVE ──────────────────┐
       │                            │
       ├─ REJECT ───────────────────┤
       │                            │
       ▼                            ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│ APPROVAL BRANCH          │  │ REJECTION BRANCH         │
└──────────────────────────┘  └──────────────────────────┘
       │                            │
       ▼                            ▼
   APPROVED                     REJECTED
   Status: SUCCESS              Status: FAILED
   admin_approved: true         rejection_reason: set
   approved_by: admin_id        approved_by: admin_id
   approved_at: timestamp       approved_at: timestamp
       │                            │
       ▼                            ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│ Update Subscription      │  │ Keep Subscription        │
│ Status: ACTIVE           │  │ Status: PENDING          │
│ payment_status: PAID     │  │ payment_status: FAILED   │
└──────────────────────────┘  └──────────────────────────┘
       │                            │
       ▼                            ▼
   COMPLETE                    COMPLETE
   Passenger can use           Passenger must resubmit
   subscription               or contact support
```

---

## 🔔 Webhook Processing Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              WEBHOOK PROCESSING WORKFLOW                        │
└─────────────────────────────────────────────────────────────────┘

SANTIMPAY GATEWAY
       │
       │ POST /api/wallet/webhook
       │ {TxnId, Status, amount, thirdPartyId, ...}
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. PARSE WEBHOOK PAYLOAD                                     │
│    - Extract all fields                                      │
│    - Normalize field names (case-insensitive)                │
│    - Handle nested data structures                           │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. EXTRACT IDENTIFIERS                                       │
│    - thirdPartyId (our transaction ID)                       │
│    - TxnId (gateway transaction ID)                          │
│    - Status (payment status)                                 │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ MISSING BOTH IDs ──► Return 400 Error
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. MATCH TRANSACTION                                         │
│    - Try: Find by refId (thirdPartyId)                       │
│    - Fallback: Find by txnId (gateway TxnId)                 │
│    - If not found: Try subscription match                    │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ NOT FOUND ──► Return 200 OK (acknowledge)
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. NORMALIZE STATUS                                          │
│    - COMPLETED/SUCCESS/APPROVED ──► "success"                │
│    - FAILED/CANCELLED/DECLINED ──► "failed"                  │
│    - Other ──► "pending"                                     │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. CHECK IDEMPOTENCY                                         │
│    - If transaction already in final state                   │
│    - Skip wallet mutation                                    │
│    - Return 200 OK                                           │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ALREADY FINAL ──► Return 200 OK
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. UPDATE TRANSACTION                                        │
│    - Set status to normalized status                         │
│    - Store gateway TxnId                                     │
│    - Store webhook data in metadata                          │
│    - Update timestamp                                        │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 7. HANDLE WALLET MUTATION (if success)                       │
│    - Find or create wallet                                   │
│    - If type="credit": ADD amount to balance                 │
│    - If type="debit": SUBTRACT amount from balance           │
│    - Update lastTransactionAt                                │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 8. ACKNOWLEDGE WEBHOOK                                       │
│    - Return 200 OK                                           │
│    - Include transaction details                             │
│    - Santimpay stops retrying                                │
└──────────────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│ COMPLETE     │
│ Webhook ✓    │
└──────────────┘
```

---

## 📊 Transaction Status Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              TRANSACTION STATUS FLOW                            │
└─────────────────────────────────────────────────────────────────┘

INITIAL STATE
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ Transaction Created                                          │
│ Status: "pending"                                            │
│ - Wallet topup initiated                                     │
│ - Subscription payment initiated                             │
│ - Awaiting webhook callback                                  │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ WEBHOOK RECEIVED ──────────────────┐
       │                                     │
       ├─ TIMEOUT (no webhook) ──────────────┤
       │                                     │
       ▼                                     ▼
┌──────────────────────────────────────────────────────────────┐
│ Status Update                                                │
│ - Parse webhook Status                                       │
│ - Normalize to "success", "failed", or "pending"             │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ SUCCESS ──────────────────┐
       │                            │
       ├─ FAILED ───────────────────┤
       │                            │
       ├─ PENDING ──────────────────┤
       │                            │
       ▼                            ▼                   ▼
┌──────────────────────────────────────────────────────────────┐
│ FINAL STATE                                                  │
│ - Wallet updated (if success)                                │
│ - Transaction immutable                                      │
│ - Metadata stored for audit                                  │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔄 Subscription Status Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              SUBSCRIPTION STATUS FLOW                           │
└─────────────────────────────────────────────────────────────────┘

CREATED
   │
   ▼
PENDING (awaiting payment)
   │
   ├─ Payment Initiated ──────────────────┐
   │                                      │
   ▼                                      ▼
PENDING (payment processing)          PENDING (no payment)
   │                                      │
   ├─ Payment Successful ──────────────┐  │
   │                                   │  │
   ├─ Payment Failed ──────────────────┤  │
   │                                   │  │
   ▼                                   ▼  ▼
ACTIVE                              PENDING
(ready to use)                      (awaiting payment)
   │
   ├─ Trip Completed ──────────────────┐
   │                                   │
   ▼                                   ▼
COMPLETED                          CANCELLED
(trip finished)                    (cancelled)
```

---

## 🎯 Error Handling Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              ERROR HANDLING WORKFLOW                            │
└─────────────────────────────────────────────────────────────────┘

REQUEST RECEIVED
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ VALIDATION ERRORS                                            │
│ - Invalid input (400)                                        │
│ - Missing fields (400)                                       │
│ - Invalid format (422)                                       │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return error response
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ AUTHORIZATION ERRORS                                         │
│ - Missing token (401)                                        │
│ - Invalid token (401)                                        │
│ - Insufficient permissions (403)                             │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return error response
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ RESOURCE ERRORS                                              │
│ - Not found (404)                                            │
│ - Already exists (409)                                       │
│ - State conflict (409)                                       │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return error response
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ GATEWAY ERRORS                                               │
│ - API error (502)                                            │
│ - Timeout (504)                                              │
│ - Invalid response (502)                                     │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return error response
       │            Log for debugging
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ SERVER ERRORS                                                │
│ - Database error (500)                                       │
│ - Unexpected error (500)                                     │
│ - Configuration error (500)                                  │
└──────────────────────────────────────────────────────────────┘
       │
       ├─ ERROR ──► Return error response
       │            Log for debugging
       │            Alert admin
       │
       ▼
    COMPLETE
```

---

**Last Updated:** 2024
**Version:** 1.0.0
