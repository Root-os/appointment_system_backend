# Santimpay Integration - Environment Setup Guide

Complete guide for configuring environment variables for Santimpay payment integration.

## 📋 Table of Contents

1. [Environment Variables Overview](#environment-variables-overview)
2. [Private Key Configuration](#private-key-configuration)
3. [Development Setup](#development-setup)
4. [Production Setup](#production-setup)
5. [Troubleshooting](#troubleshooting)

---

## 🔧 Environment Variables Overview

### Required Variables

```env
# Santimpay Configuration
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
GATEWAY_MERCHANT_ID=your-merchant-id
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook

# Private Key (choose ONE method)
PRIVATE_KEY_IN_PEM="..."
# OR
PRIVATE_KEY_BASE64="..."
# OR
PRIVATE_KEY_PATH=/path/to/key.pem
```

### Optional Variables

```env
# Debug Mode
WALLET_WEBHOOK_DEBUG=1

# Public Base URL (for webhook fallback)
PUBLIC_BASE_URL=https://your-domain.com

# Database Configuration
DB_HOST=localhost
DB_NAME=database_name
DB_USER=db_user
DB_PASSWORD=db_password

# JWT Configuration
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=7d
```

---

## 🔐 Private Key Configuration

The integration supports three methods for providing the private key, in priority order:

### Method 1: Direct PEM (Development)

**Best for:** Local development, testing

**Steps:**

1. Get your private key from Santimpay (EC private key in PEM format)
2. Add to `.env`:

```env
PRIVATE_KEY_IN_PEM="-----BEGIN EC PRIVATE KEY-----
MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49
AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92X
dcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==
-----END EC PRIVATE KEY-----"
```

**Advantages:**
- Simple setup
- Works immediately
- Good for development

**Disadvantages:**
- Not secure for production
- Commits to version control (if not careful)
- Difficult to rotate

**⚠️ Security Warning:**
- Never commit `.env` to version control
- Add `.env` to `.gitignore`
- Use only for local development

---

### Method 2: Base64 Encoded (Production Recommended)

**Best for:** Production, CI/CD pipelines, Docker

**Steps:**

1. Encode your private key in Base64:

```bash
# On Linux/Mac
cat private-key.pem | base64 -w 0

# On Windows (PowerShell)
[Convert]::ToBase64String([System.IO.File]::ReadAllBytes("private-key.pem"))
```

2. Add to `.env`:

```env
PRIVATE_KEY_BASE64=MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92XdcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==
```

3. Or set as environment variable:

```bash
export PRIVATE_KEY_BASE64="MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92XdcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g=="
```

**Advantages:**
- Secure for production
- Works with environment variables
- Easy to rotate
- Works in Docker/Kubernetes

**Disadvantages:**
- Requires encoding step
- Longer to read/debug

---

### Method 3: File Path (Containerized)

**Best for:** Docker, Kubernetes, containerized deployments

**Steps:**

1. Mount secret file in container:

```dockerfile
# Dockerfile
FROM node:18
WORKDIR /app
COPY . .
RUN npm install

# Mount secret at runtime
ENV PRIVATE_KEY_PATH=/run/secrets/private_key

CMD ["node", "index.js"]
```

2. Add to `.env`:

```env
PRIVATE_KEY_PATH=/run/secrets/private_key
```

3. Or set as environment variable:

```bash
export PRIVATE_KEY_PATH=/run/secrets/private_key
```

4. Docker Compose example:

```yaml
version: '3.8'
services:
  app:
    build: .
    environment:
      PRIVATE_KEY_PATH: /run/secrets/private_key
    secrets:
      - private_key

secrets:
  private_key:
    file: ./private-key.pem
```

5. Kubernetes example:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: santimpay-key
type: Opaque
stringData:
  private-key.pem: |
    -----BEGIN EC PRIVATE KEY-----
    MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49
    AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92X
    dcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==
    -----END EC PRIVATE KEY-----

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-service
spec:
  template:
    spec:
      containers:
      - name: app
        env:
        - name: PRIVATE_KEY_PATH
          value: /run/secrets/private_key
        volumeMounts:
        - name: private-key
          mountPath: /run/secrets
      volumes:
      - name: private-key
        secret:
          secretName: santimpay-key
          items:
          - key: private-key.pem
            path: private_key
```

**Advantages:**
- Most secure for production
- Works with secret management systems
- Easy to rotate
- Follows container best practices

**Disadvantages:**
- Requires infrastructure setup
- More complex configuration

---

## 🚀 Development Setup

### Step 1: Create `.env` file

```bash
cp .env.example .env
```

### Step 2: Fill in development values

```env
# Server
PORT=5000
NODE_ENV=development

# Database
DB_HOST=localhost
DB_NAME=santimpay_dev
DB_USER=root
DB_PASSWORD=password

# JWT
JWT_SECRET=dev-secret-key-change-in-production
JWT_EXPIRES_IN=7d

# Santimpay
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
GATEWAY_MERCHANT_ID=your-test-merchant-id

# Private Key (Development - Direct PEM)
PRIVATE_KEY_IN_PEM="-----BEGIN EC PRIVATE KEY-----
MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49
AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92X
dcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==
-----END EC PRIVATE KEY-----"

# Webhook
SANTIMPAY_NOTIFY_URL=http://localhost:5000/api/wallet/webhook
PUBLIC_BASE_URL=http://localhost:5000

# Debug
WALLET_WEBHOOK_DEBUG=1
```

### Step 3: Verify configuration

```bash
# Test that environment variables are loaded
node -e "require('dotenv').config(); console.log(process.env.GATEWAY_MERCHANT_ID)"
```

### Step 4: Start development server

```bash
npm run dev
```

---

## 🏭 Production Setup

### Step 1: Generate Base64 encoded key

```bash
# Linux/Mac
cat private-key.pem | base64 -w 0 > private-key.b64

# Windows PowerShell
[Convert]::ToBase64String([System.IO.File]::ReadAllBytes("private-key.pem")) | Out-File -NoNewline private-key.b64
```

### Step 2: Create production `.env`

```env
# Server
PORT=5000
NODE_ENV=production

# Database (Production)
DB_HOST=prod-db.example.com
DB_NAME=santimpay_prod
DB_USER=prod_user
DB_PASSWORD=strong-password-here

# JWT
JWT_SECRET=production-secret-key-very-long-and-random
JWT_EXPIRES_IN=7d

# Santimpay
SANTIMPAY_BASE_URL=https://services.santimpay.com/api/v1/gateway
GATEWAY_MERCHANT_ID=your-production-merchant-id

# Private Key (Production - Base64)
PRIVATE_KEY_BASE64=MHcCAQEEIP5pYcH2zlnBljLcY6EXc66K/9QKRvwskCy+dLtK3rlYoAoGCCqGSM49AwEHoUQDQgAEJ8kqGGD5qinG9w8MI1t8PyLl6aUIqSJJ0Y6vnVWA7fvGQIi8E92XdcxhKi0EHL/Sa6j1gQsE4p5yJvipPlbJ1g==

# Webhook
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook
PUBLIC_BASE_URL=https://your-domain.com

# Debug (Disabled in production)
WALLET_WEBHOOK_DEBUG=0
```

### Step 3: Secure the `.env` file

```bash
# Restrict file permissions
chmod 600 .env

# Verify permissions
ls -la .env
# Should show: -rw------- (600)
```

### Step 4: Add to `.gitignore`

```bash
echo ".env" >> .gitignore
echo ".env.local" >> .gitignore
echo ".env.*.local" >> .gitignore
echo "private-key.pem" >> .gitignore
echo "private-key.b64" >> .gitignore
```

### Step 5: Deploy

```bash
# Using PM2
pm2 start index.js --name "payment-service"

# Using Docker
docker build -t payment-service .
docker run -d --env-file .env payment-service

# Using systemd
sudo systemctl start payment-service
```

---

## 🐳 Docker Setup

### Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application
COPY . .

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:5000/health', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})"

# Start application
CMD ["node", "index.js"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      NODE_ENV: production
      PORT: 5000
      DB_HOST: db
      DB_NAME: santimpay_prod
      DB_USER: user
      DB_PASSWORD: password
      GATEWAY_MERCHANT_ID: ${GATEWAY_MERCHANT_ID}
      PRIVATE_KEY_BASE64: ${PRIVATE_KEY_BASE64}
      SANTIMPAY_NOTIFY_URL: https://your-domain.com/api/wallet/webhook
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: mysql:8
    environment:
      MYSQL_DATABASE: santimpay_prod
      MYSQL_USER: user
      MYSQL_PASSWORD: password
      MYSQL_ROOT_PASSWORD: root_password
    volumes:
      - db_data:/var/lib/mysql
    restart: unless-stopped

volumes:
  db_data:
```

---

## 🔍 Troubleshooting

### Issue: "Missing PRIVATE_KEY"

**Error:**
```
Error: SantimPay config error: missing PRIVATE_KEY
```

**Solution:**

1. Check that ONE of these is set:
   - `PRIVATE_KEY_IN_PEM`
   - `PRIVATE_KEY_BASE64`
   - `PRIVATE_KEY_PATH`

2. Verify the value is not empty:
```bash
echo $PRIVATE_KEY_IN_PEM
echo $PRIVATE_KEY_BASE64
echo $PRIVATE_KEY_PATH
```

3. Check `.env` file syntax:
```bash
# Should see your key
cat .env | grep PRIVATE_KEY
```

---

### Issue: "Invalid private key"

**Error:**
```
Error: error:0906D06C:PEM routines:PEM_read_bio:no start line
```

**Solution:**

1. Verify key format:
```bash
# Should start with -----BEGIN EC PRIVATE KEY-----
head -1 private-key.pem

# Should end with -----END EC PRIVATE KEY-----
tail -1 private-key.pem
```

2. Check for encoding issues:
```bash
# Verify Base64 encoding
echo $PRIVATE_KEY_BASE64 | base64 -d | head -1
# Should show: -----BEGIN EC PRIVATE KEY-----
```

3. Ensure no extra whitespace:
```bash
# Remove trailing newlines
sed -i 's/[[:space:]]*$//' private-key.pem
```

---

### Issue: "GATEWAY_MERCHANT_ID not configured"

**Error:**
```
Error: SantimPay config error: missing GATEWAY_MERCHANT_ID env
```

**Solution:**

1. Add to `.env`:
```env
GATEWAY_MERCHANT_ID=your-merchant-id-here
```

2. Verify it's loaded:
```bash
node -e "require('dotenv').config(); console.log(process.env.GATEWAY_MERCHANT_ID)"
```

---

### Issue: "Webhook URL not configured"

**Error:**
```
Error: SANTIMPAY_NOTIFY_URL is not configured
```

**Solution:**

1. Add to `.env`:
```env
SANTIMPAY_NOTIFY_URL=https://your-domain.com/api/wallet/webhook
```

2. Verify URL is accessible:
```bash
curl -X POST https://your-domain.com/api/wallet/webhook \
  -H "Content-Type: application/json" \
  -d '{"test": true}'
```

---

### Issue: "Invalid phone format"

**Error:**
```
Missing or invalid passenger phone; please ensure the token contains a valid +2519XXXXXXXX.
```

**Solution:**

1. Ensure JWT token includes phone field:
```javascript
const token = {
  id: 'user-123',
  type: 'passenger',
  phone: '+251911223344'  // Required!
};
```

2. Phone must be Ethiopian format:
   - ✅ `+251911223344`
   - ✅ `0911223344` (converted to +251911223344)
   - ✅ `911223344` (converted to +251911223344)
   - ❌ `+1234567890` (non-Ethiopian)

---

## ✅ Verification Checklist

- [ ] `.env` file created
- [ ] `GATEWAY_MERCHANT_ID` set
- [ ] Private key configured (one method)
- [ ] `SANTIMPAY_NOTIFY_URL` set
- [ ] Database variables configured
- [ ] JWT secret configured
- [ ] `.env` added to `.gitignore`
- [ ] Environment variables verified with `echo`
- [ ] Application starts without errors
- [ ] Webhook endpoint is accessible

---

**Last Updated:** 2024
**Version:** 1.0.0
